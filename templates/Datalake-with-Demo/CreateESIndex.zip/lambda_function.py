import boto3
import os
import json
import urllib
from boto3 import client
from elasticsearch import Elasticsearch, RequestsHttpConnection
from botocore.vendored import requests
CFN_SUCCESS = 'SUCCESS'
CFN_FAILED = 'FAILED'
s3 = boto3.client('s3')
client = boto3.client('es', region_name=os.environ['region'])

def send_cfnresponse(event, context, response_status):
    response_url = event['ResponseURL']
    print('CFN response url: {}'.format(response_url))

    response_body = dict()
    response_body['Status'] = response_status
    response_body['Reason'] = 'See the details in CloudWatch Log Stream: ' + context.log_stream_name
    response_body['PhysicalResourceId'] = context.log_stream_name
    response_body['StackId'] = event['StackId']
    response_body['RequestId'] = event['RequestId']
    response_body['LogicalResourceId'] = event['LogicalResourceId']
    response_body['Data'] = {}

    json_response = json.dumps(response_body)
    print("Response body:\n" + json_response)

    headers = {
        'content-type': '',
        'content-length': str(len(json_response))
    }

    try:
        response = requests.put(response_url, data=json_response, headers=headers)
        print("Status code: " + response.reason)
    except Exception as e:
        print("send(..) failed executing requests.put(..): " + str(e))



def lambda_handler(event, context):
    indexDoc = {
        "dataRecord": {
            "properties": {
                "createdDate": {
                    "type": "date",
                    "format": "dateOptionalTime"
                },
                "objectKey": {
                    "type": "string",
                    "format": "dateOptionalTime"
                },
                "content_type": {
                    "type": "string"
                },
                "content_length": {
                    "type": "long"
                },
                "metadata": {
                    "type": "object"
                }
            }
        },
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0
        },
        "mappings": {
            "datalake-metadata-3": {
                "properties": {
                    "GEOLOCATION": {"type": "geo_point"}
                }
            }
        }
    }
    # esEndPoint="search-metadata-es-f37x5mq24	tm4wozcwhwuo65rmu.us-west-2.es.amazonaws.com"
    esEndPoint = os.environ['esEndPoint']

    if event['RequestType'] == 'Create':
        print ('Connecting to the ES Endpoint {0}'.format(esEndPoint))
        try:
            esClient = Elasticsearch(
                hosts=[{'host': esEndPoint, 'port': 443}],
                use_ssl=True,
                verify_certs=True,
                connection_class=RequestsHttpConnection)
            print(esClient)

            response_state = client.describe_elasticsearch_domain_config(
                DomainName='yash-datalake-quickstart'
            )

            print(response_state)
            res = esClient.indices.exists('stream-metadata')
            print(res)
            if res is False:
                print("Index NOT EXIST")
                esClient.indices.create('stream-metadata', body=indexDoc)
                print("After Created")
                return send_cfnresponse(event, context, CFN_SUCCESS)
            else:
                return send_cfnresponse(event, context, CFN_FAILED)
        except Exception as E:
            print("Unable to Create Index {0}".format("stream-metadata"))
            print(E)
            return send_cfnresponse(event, context, CFN_FAILED)

    else:
        return send_cfnresponse(event, context, CFN_FAILED)
