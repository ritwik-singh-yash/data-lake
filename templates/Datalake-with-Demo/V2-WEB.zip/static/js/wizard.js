$(document).ready(function() {
document.getElementById("navigate_to_ccds").addEventListener("click", function(event){
	event.preventDefault();
	window.location.href = 'ccds.html'
	});    

});

