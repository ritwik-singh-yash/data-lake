function customer_id(){
var customer_id_arr = ["6822c044-de83-346d-f4a6-375b1dd71b56","35610499-4986-85f7-b158-5edd3b0ad4b5","8ed4af67-7afb-3fdb-021e-88a2ae651b62","c56f692c-7e2e-8866-f747-c89eca66e619","7c56789d-51d1-1ae5-ca51-927be78f85aa","21592602-fb62-509c-e29a-aa3ef25bdbac","21a35709-ae02-a9f4-8006-aff375dca0bb","c16466f1-0bc8-523a-256a-cf61f8563a9c","eb68d9ad-8384-0713-1214-1a9ddaafb0e7","6da57802-6ae1-c6b9-a0af-5c0e4b5bf761"];
return customer_id_arr;
}


