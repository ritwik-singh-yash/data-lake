from chalice import Chalice, Response
from chalice import CognitoUserPoolAuthorizer

import os
import boto3
import psycopg2 
import urllib
from chalicelib.glue_crawler import start_crawler
from chalicelib.glue_job import start_job
import requests
try:
    import ConfigParser as parser
except:
    import configparser as  parser  # In Python 3, ConfigParser has been renamed to configparser for PEP 8 compliance.

properties = {}
app = Chalice(app_name='yash_aws_quick_start-datalake')
app.debug = True
resource = boto3.resource('s3')

authorizer = CognitoUserPoolAuthorizer('CognitoAuthorizer', provider_arns=[os.environ['cognito_pool_arn']])
#authorizer = CognitoUserPoolAuthorizer('CognitoAuthorizer', ['arn:aws:cognito-idp:us-west-2:754307369999:userpool/us-west-2_IqRcBFaNu'])


@app.route("/prop", authorizer=authorizer, methods=['GET'], cors=True)
def read_properties():
    config = parser.ConfigParser()
    bucket_name = os.environ['destination_bucket_name']
    file_name = os.environ['properties_file_name']
    try:
        resource.Bucket(bucket_name).download_file(file_name, '/tmp/appconfig.ini')
    except Exception as e:
        return {"error": e, "success": False}
    try:
        config.read('/tmp/appconfig.ini')

        properties['region'] = config.get('aws', 'region')
        properties['glue_endpoint'] = config.get('aws', 'glue_endpoint')

        # name of four crawlers created via CF retrive from .ini and stored in properties dict
        properties['crawler_on_raw_bucket'] = config.get('aws', 'rawcrawler')
        properties['crawler_on_transfromed_bucket'] = config.get('aws', 'transformedcrawler')
        properties['crawler_on_redshift_data'] = config.get('aws', 'redshiftcrawler')
        properties['crawler_on_published_bucket'] = config.get('aws', 'publishedcrawler')

        # name of five jobs created via CF retrive from .ini and stored in properties dict
        properties['raw_to_transformed_job'] = config.get('aws', 'rawtotransformedjob')
        properties['transformed_to_redshift_job'] = config.get('aws', 'transformedtoredshiftjob')
        properties['run_redshift_analytics_queries_job'] = config.get('aws', 'redshiftanalyticsqueriesjob')
        properties['redshift_to_transformed_job'] = config.get('aws', 'redshifttotransformedjob')
        properties['transformed_to_published_job'] = config.get('aws', 'transformedtopublishedjob')
        properties['redshift_spectrum_create_external_schema_job'] = config.get('aws', 'redshift_spectrum_create_external_schema_job')
        properties['raw_bucket_name'] = config.get('aws', 'rawbucket')

        return {"success":True}
    except Exception as e:
        return {"error": e, "success": False}
    
@app.route('/getProperties', methods=['GET'], authorizer=authorizer,cors=True)
def authenticated():
    return {"success": properties}

@app.route('/getSignInToken', methods=['POST'],authorizer=authorizer, cors=True)
def create_signintoken():
    try:
        
        data = app.current_request.json_body
        URL=data['url']
        print("URL",URL)
        r = requests.get(url=URL)
        resData = r.json()
        print(resData['SigninToken'])
        return Response(body={'SigninToken':resData['SigninToken']},
                        status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e),
                        status_code=500,
                        headers={'Content-Type': 'text/plain'})	
	

@app.route('/add-incremental_data', methods=['GET'], cors=True, authorizer=authorizer)
def copy_incremental_data_to_raw_bucket():
    try:
        url='https://s3.amazonaws.com/yash-quickstart-datalake-datasets/quickstart-datalake-yash/data/v3-incremental/products/newproducts2016part2.csv'
        fileName=url.rsplit('/', 1)[1]
        keyName='products/'+fileName
        raw_bucket_name=os.environ['raw_bucket_name']
        urllib.urlretrieve(url, "/tmp/"+fileName)
        resource.meta.client.upload_file('/tmp/'+fileName,raw_bucket_name,keyName ,ExtraArgs={'ACL':'public-read'})
        
        return Response(body={'file_upload':'success'},
                        status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e),
                        status_code=500,
                        headers={'Content-Type': 'text/plain'})


@app.route('/crawler', methods=['GET'], cors=True, authorizer=authorizer)
def start_crawler_on_raw_bucket():
    try:
        CrawlerName = os.environ['crawler_on_raw_bucket']
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        crawler_name = start_crawler(CrawlerName, region, glue_endpoint)
        return Response(body=crawler_name,
                        status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e),
                        status_code=500,
                        headers={'Content-Type': 'text/plain'})


@app.route('/rawtransformetl', methods=['GET'], cors=True, authorizer=authorizer)
def start_raw_to_transformed_job():
    try:
        JobName = os.environ['raw_to_transformed_job']
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        job_name_and_id = start_job(JobName, region, glue_endpoint)
        return Response(body={'job_name_and_id': job_name_and_id},
                        status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e),
                        status_code=500,
                        headers={'Content-Type': 'text/plain'})


@app.route('/transformcrawler', methods=['GET'], cors=True, authorizer=authorizer)
def start_crawler_on_transfromed_bucket():
    try:
        CrawlerName = os.environ['crawler_on_transfromed_bucket']
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        crawler_name = start_crawler(CrawlerName, region, glue_endpoint)
        return Response(body=crawler_name,
                        status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e),
                        status_code=500,
                        headers={'Content-Type': 'text/plain'})


@app.route('/transformedredshift', methods=['GET'], cors=True, authorizer=authorizer)
def start_transformed_to_redshift_job():
    try:
        JobName = os.environ['transformed_to_redshift_job']
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        job_name_and_id = start_job(JobName, region, glue_endpoint)
        return Response(body={'job_name_and_id': job_name_and_id},
                        status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e),
                        status_code=500,
                        headers={'Content-Type': 'text/plain'})

@app.route('/redshift', methods=['GET'], cors=True, authorizer=authorizer)
def run_redshift_create_schema_command():
    try:
        JobName = os.environ['redshift_spectrum_create_external_schema_job']       
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        job_name_and_id = start_job(JobName, region, glue_endpoint)
        return Response(body={'job_name_and_id': job_name_and_id},
                        status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e),
                        status_code=500,
                        headers={'Content-Type': 'text/plain'})

@app.route('/redshiftanalyticsqueries', methods=['GET'], cors=True, authorizer=authorizer)
def start_run_redshift_analytics_queries_job():
    try:
        JobName = os.environ['run_redshift_analytics_queries_job']
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        job_name_and_id = start_job(JobName, region, glue_endpoint)
        return Response(body={'job_name_and_id': job_name_and_id},
                        status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e), status_code=500,
                        headers={'Content-Type': 'text/plain'})


@app.route('/runredshiftcrawler', methods=['GET'], cors=True, authorizer=authorizer)
def start_crawler_on_redshift_data():
    try:
        CrawlerName = os.environ['crawler_on_redshift_data']
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        crawler_name = start_crawler(CrawlerName, region, glue_endpoint)
        return Response(body=crawler_name,
                        status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e), status_code=500,
                        headers={'Content-Type': 'text/plain'})


@app.route('/redshifttotransformcopy', methods=['GET'], cors=True, authorizer=authorizer)
def start_redshift_to_transformed_job():
    try:
        JobName = os.environ['redshift_to_transformed_job']
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        job_name_and_id = start_job(JobName, region, glue_endpoint)
        return Response(body={'job_name_and_id': job_name_and_id}, status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e), status_code=500,
                        headers={'Content-Type': 'text/plain'})


@app.route('/run_crawler', methods=['GET'], cors=True, authorizer=authorizer)
def start_crawler_on_transfromed_bucket():
    try:
        CrawlerName = os.environ['crawler_on_transfromed_bucket']
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        crawler_name = start_crawler(CrawlerName, region, glue_endpoint)
        return Response(body=crawler_name, status_code=200, headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e), status_code=500,
                        headers={'Content-Type': 'text/plain'})


@app.route('/run_transform_to_publish_job', methods=['GET'], cors=True, authorizer=authorizer)
def start_transformed_to_published_job():
    try:
        JobName = os.environ['transformed_to_published_job']
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        job_name_and_id = start_job(JobName, region, glue_endpoint)
        return Response(body={'job_name_and_id': job_name_and_id}, status_code=200,
                        headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e), status_code=500,
                        headers={'Content-Type': 'text/plain'})


@app.route('/create_run_publish_crawler', methods=['GET'], cors=True, authorizer=authorizer)
def start_crawler_on_published_bucket():
    try:
        CrawlerName = os.environ['crawler_on_published_bucket']
        region = os.environ['region']
        glue_endpoint = os.environ['glue_endpoint']
        crawler_name = start_crawler(CrawlerName, region, glue_endpoint)
        return Response(body=crawler_name, status_code=200, headers={'Content-Type': 'text/plain'})
    except Exception as e:
        return Response(body='Lambda call failed due to:' + str(e), status_code=500,
                        headers={'Content-Type': 'text/plain'})


