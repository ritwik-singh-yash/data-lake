import boto3


def start_job( jobName, region, endpoint):
    try:
        glue = boto3.client(service_name='glue', region_name=region, endpoint_url=endpoint)
        Dict = glue.start_job_run(JobName=jobName)
        return {'Jobname': jobName, 'jobID': Dict['JobRunId']}
    except Exception as e:
        raise e