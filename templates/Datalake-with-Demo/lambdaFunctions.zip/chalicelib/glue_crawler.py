import boto3

def start_crawler(crawName, region, endpoint):
    try:
        glue = boto3.client(service_name='glue', region_name=region, endpoint_url=endpoint)
        response = glue.start_crawler(Name=crawName)
        return {'Crawler_Name':crawName}
    except Exception as e:
        raise e