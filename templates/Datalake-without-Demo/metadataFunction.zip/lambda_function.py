from __future__ import print_function
from pprint import pprint
import boto3
import json
from elasticsearch import Elasticsearch, RequestsHttpConnection

import os
import urllib
import json
import requests

s3 = boto3.client('s3')
batch_index = 'batch-metadata'
stream_index = 'stream-metadata'
BATCH_KIBANA_JSON_PATH = 'kibana/batch_metadata_dashboard.json'
STREAM_KIBANA_JSON_PATH = 'kibana/stream_metadata_dashboard.json'

print('Loading function')

def connectES(esEndPoint):
    print ('Connecting to the ES Endpoint {0}'.format(esEndPoint))
    try:
        esClient = Elasticsearch(
            hosts=[{'host': esEndPoint, 'port': 443}],
            use_ssl=True,
            verify_certs=True,
            connection_class=RequestsHttpConnection)
        return esClient
    except Exception as E:
        print("Unable to connect to {0}".format(esEndPoint))
        print(E)
        exit(3)

def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))
    
    # Get the object from the event and show its content type
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.unquote_plus(event['Records'][0]['s3']['object']['key'].encode('utf8'))

    esClient = connectES(os.environ['ES_endpoint'])
    urlForDashboard = "https://" + os.environ['ES_endpoint'] + "/.kibana/_mapping/dashboard"
    dashboardMapping = {"dashboard": {
        "properties": {"title": {"type": "string"}, "hits": {"type": "integer"}, "description": {"type": "string"},
                       "panelsJSON": {"type": "string"}, "optionsJSON": {"type": "string"},
                       "uiStateJSON": {"type": "string"}, "version": {"type": "integer"},
                       "timeRestore": {"type": "boolean"}, "timeTo": {"type": "string"}, "timeFrom": {"type": "string"},
                       "kibanaSavedObjectMeta": {"properties": {"searchSourceJSON": {"type": "string"}}}}}};
    dashboardData = requests.put(urlForDashboard, data=json.dumps(dashboardMapping));

    esClient.index(index='.kibana', doc_type='config', id='5.1.1', body=json.dumps({'defaultIndex': 'batch-metadata'}))
    kibana_index_batch = {'title': batch_index, 'timeFieldName': 'LastModified'}
    esClient.index(index='.kibana', doc_type='index-pattern', id='batch-metadata', body=json.dumps(kibana_index_batch))
    with open(BATCH_KIBANA_JSON_PATH) as visualizations_file:
        visualizations = json.load(visualizations_file)
    for visualization in visualizations:
        esClient.index(
            index='.kibana',
            doc_type=visualization['_type'],
            id=visualization['_id'],
            body=json.dumps(visualization['_source'])
        )
    
    kibana_index_stream = {'title': stream_index, 'timeFieldName': 'HOUR_MINUTE'}
    esClient.index(index='.kibana', doc_type='index-pattern', id=stream_index, body=json.dumps(kibana_index_stream))
    with open(STREAM_KIBANA_JSON_PATH) as visualizations_file:
        visualizations = json.load(visualizations_file)
    for visualization in visualizations:
        esClient.index(
            index='.kibana',
            doc_type=visualization['_type'],
            id=visualization['_id'],
            body=json.dumps(visualization['_source'])
        )
    
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
	esClient.index(index=batch_index, doc_type=bucket, body={
		'Key': key,
		'ContentType': response['ContentType'],
		'LastModified': response['LastModified'].isoformat(),
		'ContentLength': response['ContentLength'],
		'metadata': json.dumps(response['Metadata']),
		'SizeMiB': response['ContentLength'] / 1024**2,
        'ETag': response['ETag'],
        'Dataset': key.split('/')[0]
    })
        return response['ContentType']
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e