See https://github.com/davidmuller/aws-requests-auth for installation and usage instructions.


