from setuptools import setup

setup(
    name='datalake_quickstart',
    version='1.0',
)
